-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2020 at 11:17 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `first` varchar(100) NOT NULL,
  `last` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `first`, `last`, `username`, `password`, `email`, `contact`, `pic`) VALUES
(1, 'Mr.', 'Abdul', 'Hamid', '123456', 'mr.hamid@gmail.com', '12345678', 'p.jpg'),
(2, 'Kamrul', 'Ahmed', 'kamrul', '1234', 'test@gmail.com', '012345678', 'rony.jpg'),
(3, 'Mr.', 'X', 'X', '222222', 'samiarahman@gmail.com', '133446557', 'p.jpg'),
(4, 'Kamrul', 'Hasan', 'Hasan', '1234', 'test9@gmail.com', '01858199861', 'rony.jpg'),
(5, 'Md Azizul ', 'Islam', 'Md Azizul Islam', '1234', 'isazdu@yahoo.com', '01713815415', 'Screenshot_9.png'),
(6, 'Kamrun ', 'Nahar', 'Kamrun Nahar', '1234', 'knahar@gmail.com', '01900454957', 'Screenshot_10.png'),
(7, 'Md Kamal ', 'Hossain', 'Md Kamal Hossain', '1234', 'kamal@gmail.com', '01915137586', 'Screenshot_1.png'),
(8, 'RONY', 'MOULY', 'mouly', '1234', 'test@gmail.com', '0998877', '103750383_196186321616559_1144388492644851483_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `bid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `authors` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`bid`, `name`, `authors`, `edition`, `status`, `quantity`, `department`) VALUES
(1, 'Principal of electronics', 'V.K. Mehta, Rohit Mehta', '3rd', 'Available', 3, 'EEE'),
(2, 'The Complete Reference C++', 'Herbert Schildt', '4th', 'Available', 1, 'CSE'),
(3, 'Data Structure', 'Seymour Lipschutz', '4th', 'Available', 2, 'ECE'),
(4, 'Graph Theory', 'Narsingh Deo', '3rd', 'Available', 14, 'CSE'),
(5, 'Learn Java', 'Jamie Chan', '5th', 'Available', 21, 'CSE'),
(6, 'Electric circuits & field', 'Sadiku', '2nd', 'Available', 15, 'EEE'),
(7, 'Digital Design', 'M. Moris Mano', '2nd', 'Not Available', -1, 'EEE'),
(8, 'Discrete Mathematics', 'Schaums Series', '5th', 'Not Available', 0, 'CSE'),
(9, 'Signal & System', 'Haykin', '2nd', 'Not Available', -1, 'EEE'),
(10, 'Numerical Method', 'BS Grewal', '6th', 'Available', 12, 'CSE'),
(11, 'Matrix Analysis', 'Ronald L Sock', '5th', 'Available', 23, 'Math'),
(12, 'Project Management', 'Harold Kerzner', '4th', 'Not Available', 20, 'Cvil'),
(13, 'Financial Accounting', 'Dr SN Moheshwari', '3rd', 'Available', 15, 'BBA'),
(14, 'Management Accounting', 'Dr S Gupta', '5th', 'Available', 14, 'BBA'),
(15, 'Elementary Calculus', 'H. Jarome ', '5th', 'Not Available', 0, 'Math');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `comment` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `username`, `comment`) VALUES
(23, 'Kamrul Razib Mouly', 'Hi Sir.'),
(24, 'Admin', 'Hello.'),
(25, 'Kamrul Razib Mouly', 'Can you give me some information? sir.'),
(26, 'Admin', 'Yes, How can i help you?'),
(27, 'Kamrul Razib Mouly', 'I needed some books.'),
(28, 'Admin', 'Which book do you need?');

-- --------------------------------------------------------

--
-- Table structure for table `fine`
--

CREATE TABLE `fine` (
  `username` varchar(100) NOT NULL,
  `bid` int(100) NOT NULL,
  `returned` varchar(100) NOT NULL,
  `day` int(50) NOT NULL,
  `fine` double NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fine`
--

INSERT INTO `fine` (`username`, `bid`, `returned`, `day`, `fine`, `status`) VALUES
('Promi', 1, '2019-05-21', 31, 3.1, 'not paid'),
('Afifa', 1, '2019-05-21', 1, 0.1, 'not paid'),
('Kamrul Razib Mouly', 5, '2020-06-19', 0, 0, 'not paid'),
('Kamrul Razib Mouly', 5, '2020-06-19', 0, 0, 'not paid'),
('Afifa', 1, '2020-06-20', 18432, 1843.2, 'not paid');

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `username` varchar(100) NOT NULL,
  `bid` int(100) NOT NULL,
  `approve` varchar(100) NOT NULL,
  `issue` varchar(100) NOT NULL,
  `return` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`username`, `bid`, `approve`, `issue`, `return`) VALUES
('Promi', 3, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '2019-04-22', '2019-05-16'),
('Promi', 1, '<p style=\"color:yellow; background-color:green;\">RETURNED</p>', '2019-03-20', '2019-04-20'),
('Promi', 2, '<p style=\"color:yellow; background-color:green;\">RETURNED</p>', '2019-01-30', '2019-02-28'),
('Afifa', 1, '<p style=\"color:yellow; background-color:green;\">RETURNED</p>', '12/01/2020', '23/02/2020'),
('Afifa', 2, '<p style=\"color:yellow; background-color:green;\">RETURNED</p>', '2019-02-20', '2019-02-10'),
('Afifa', 1, '<p style=\"color:yellow; background-color:green;\">RETURNED</p>', '12/01/2020', '23/02/2020'),
('rony', 2, 'yes', '19/06/2020', '2020/07/15'),
('rony', 3, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '2019/08/11', '2019/08/25'),
('md kamrul hasan', 2, 'yes', '2020/06/18', '2020/07/18'),
('md kamrul hasan', 7, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '01/07/2020', '03/08/2020'),
('md kamrul hasan', 5, 'yes', '2020/06/18', '2020/07/15'),
('md kamrul hasan', 10, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '01/07/2020', '03/08/2020'),
('md kamrul hasan', 9, '', '', ''),
('nabila naher mouly', 5, '', '', ''),
('nabila naher mouly', 4, '', '', ''),
('nabila naher mouly', 12, '', '', ''),
('md razib howlader', 2, '', '', ''),
('md razib howlader', 9, '', '', ''),
('md razib howlader', 4, '', '', ''),
('kamrul razib mouly', 3, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '19/06/2020', '15/07/2020'),
('kamrul razib mouly', 7, '', '', ''),
('kamrul razib mouly', 4, 'yes', '19/06/2020', '25/07/2020'),
('kamrul razib mouly', 5, '<p style=\"color:yellow; background-color:green;\">RETURNED</p>', '12/02/2020', '12/03/2020'),
('kamrul razib mouly', 8, '', '', ''),
('kamrul razib mouly', 11, '', '', ''),
('kamrul razib mouly', 2, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '13/06/2020', '06/07/2020'),
('Kamrul Razib Mouly', 9, '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', '12/06/2020', '05/07/2020'),
('Kamrul Razib Mouly', 10, 'yes', '01/06/2020', '23/07/2020'),
('Kamrul Razib Mouly', 6, '', '', ''),
('Kamrul Razib Mouly', 1, '', '', ''),
('md kamrul hasan ', 3, '', '', ''),
('kamrul razib mouly', 9, '', '', ''),
('test1', 7, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `first` varchar(100) NOT NULL,
  `last` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `roll` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`first`, `last`, `username`, `password`, `roll`, `email`, `contact`, `pic`) VALUES
('Afia', 'Abida', 'Promi', '111111', 1, 'afia1@gmail.com', '000000000', '7996_3d_modeling_5.jpg'),
('sanzida', 'mou', 'Mim', '555555', 324, 'mim@gmail.com', '53454', 'p.jpg'),
('Mr.', 'Rahman', 'Rahman', '212324', 1510016, 'samiarahman@gmail.com', '123456', 'p.jpg'),
('Sumaiya', 'Shimu', 'Shimu1', '987654', 1510052, 'shimu1@gmail.com', '1739000000', 'p.jpg'),
('Suchana', 'Pramanik', 'Suchana', '121212', 1510047, 'suchana@gmail.com', '1739000000', 'p.jpg'),
('Afifa ', 'Ashraf', 'Afifa', '121212', 1510047, 'afifa@gmail.com', '1739000001', 'p.jpg'),
('Rony', 'Ahsan', 'rony', '1234', 101018, 'cs@gmail.com', '01832139473', ''),
('Rony', 'Ahmed', 'test', '1234', 123456, 'test9@gmail.com', '01832139474', 'rony.jpg'),
('Nabila', 'Mouly', 'Mouly', '12345', 1029, 'mou7@gmail.com', '568965544', 'Screenshot_20200116-152640_1.jpg'),
('Razib', 'Ashan', 'razib', '1234', 1028, 'rz2@gmail.com', '928092137', '57162555_1980415895421531_8396509073377329152_n.jpg'),
('Kamrul Razib', 'Mouly', 'Kamrul Razib Mouly', '1234', 182829, 'rony.mouly.razib@gmail.com', '01858199861', 'P_20190714_132415_BF.jpg'),
('Md Kamrul', 'Hasan', 'Md Kamrul Hasan', '1234', 2147483647, 'cserony9@gmail.com', '01858199861', 'rony.jpg'),
('Nabila Naher', 'Mouly', 'Nabila Naher Mouly', '1234', 2147483647, 'csemouly28@gmail.com', '01876948418', '103750383_196186321616559_1144388492644851483_n.jpg'),
('Md Razib', 'Howlader', 'Md Razib Howlader', '1234', 2147483647, 'cserazib30@gmail.com', '01714809061', '103418492_278287030205423_7035777658210263945_n.jpg'),
('Sazzad', 'Hossain', 'sazzad', '1234', 2147483647, 'sazzad12@gmail.com', '01713815415', 'p.jpg'),
('Md Borkat', 'Ullah', 'Borkat', '1234', 2147483647, 'borkat2@gmail.com', '01713815415', 'p.jpg'),
('Anisur', 'Rahman', 'anisur', '1234', 2147483647, 'ar12@gmail.com', '01713815415', 'p.jpg'),
('Md', 'Dipu', 'dipu', '1234', 2147483647, 'dipu@gmail.com', '01713815415', 'p.jpg'),
('Md kamrul', 'Hasan', 'test1', '1234', 1018, 'cserony9@gmail.com', '01713815415', 'p.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
